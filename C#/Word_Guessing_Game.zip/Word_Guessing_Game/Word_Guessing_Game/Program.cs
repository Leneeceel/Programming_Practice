﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

/* The solution created by Lanicel Hwang
 * It is a word guessing game.
 * A user has unlimited chances to guess a letter in a word.
 * The program ends when a user has guessed all the letters 
 *  in the word correctly.
 */
namespace Word_Guessing_Game
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] words = { "water", "jackass", "rum", "vodka",
                               "starcraft", "game", "program", "excel" };
            string randomWord;
            //char[] randomWordHidden = new char[10];
            List<char> randomWordHidden = new List<char>();
            string aLetterInput;
            bool isGameComplete = false;
            bool isRightLetter = false;
            int randomNum;
            int letterCount = 0;

            //pick a random number to get a random word.
            Random randomGenerator = new Random();
            randomNum = randomGenerator.Next(0, words.Length - 1);

            //A random word is selected.
            randomWord = words[randomNum];

            //store * as many as letters in the word.
            for (int i = 0; i < randomWord.Length; i++)
                //randomWordHidden[i] = '*';
                randomWordHidden.Add('*');

            //while the game is not complete.
            while (!isGameComplete)
            {
                //display *s.
                foreach (char c in randomWordHidden)
                    Write(c);
                WriteLine("");
                //WriteLine(randomWordHidden);
                Write("Guess a letter >> ");
                aLetterInput = ReadLine();

                //compare the user input to each letter in the word.
                for (int i = 0; i < randomWord.Length; i++)
                {
                    //if it's a correct guess,
                    if (Equals(aLetterInput, randomWord.Substring(i, 1)))
                    {
                        isRightLetter = true;
                        //change * to the user input.
                        randomWordHidden[i] = Char.ToLower(Convert.ToChar(aLetterInput));
                        
                        //letterCount increases by 1 when the guess is correct.
                        letterCount++;
                    }
                }

                //let the user know if their guess is correct or not.
                if (isRightLetter)
                    WriteLine("Yes! {0} is in the word!\n", aLetterInput);
                else
                    WriteLine("Sorry, {0} is not in the word.\n", aLetterInput);

                //set it to false for the next guess.
                isRightLetter = false;

                //When a user has revealed all the letters,
                //the game ends.
                if (letterCount == randomWord.Length)
                    isGameComplete = true;

            }

            WriteLine("The letter is {0}!", randomWord);
            WriteLine("You have completed the game!\nCongratulations!\n");

        }
    }
}
